from urllib import request
from django.http import HttpResponseNotAllowed
from django.shortcuts import render
from django.shortcuts import render
from .models import Todo
from django.shortcuts import HttpResponseRedirect
from todo_app.models import Todo
from django.urls import reverse

# url = ''
def index(request):
    _todos = Todo.objects.all()
    return render(request,'index.html',{'todos':_todos})


def create_todo(request): # todolist에서 등록을 하는 함수
    content = request.POST['todoContent']
    new_todo = Todo(title=content)
    new_todo.save()
    return HttpResponseRedirect(reverse('index'))

def delete_todo(request, todoNum): # todolist에서 삭제하는 함수
    if request.method == 'GET':
        _id = todoNum
        todo = Todo.objects.get(id=_id)
        todo.delete()
        return HttpResponseRedirect(reverse('index'))
    else:
        # GET 요청이 아닌 경우에는 다른 처리를 하거나 에러를 반환할 수 있습니다.
        return HttpResponseNotAllowed(['GET'])
